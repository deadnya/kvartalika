import { Link, useNavigate } from "react-router-dom";
import type { FormEvent } from "react";
import { useUIStore } from "../store/ui.store.ts";
import "./AboutUsPage.css";

const FILES_BASE = "https://kvartalika.ru/api/files/about_us";

const AboutUsPage = () => {
    const navigate = useNavigate();
    const setBidForm = useUIStore(s => s.setBidForm);
    const bidForm = useUIStore(s => s.bidForm) || { name: "", phone: "" };
    const submitBid = useUIStore(s => s.submitBid);

    const handleSubmit = async (e: FormEvent) => {
        e.preventDefault();
        try {
            await submitBid();
        } catch (err) {
            console.error(err);
        }
    };

    const handleInputChange = (field: string, value: string) => {
        setBidForm({ [field]: value });
    };

    return (
        <div className="about-us">
            <img
                className="image"
                src={`${FILES_BASE}/about-us-1.png`}
                alt="Визуальный блок о компании"
                loading="lazy"
            />

            <section className="about-us-description">
                <nav>
                    <div className="breadcrumbs">
                        <Link to="/">Главная</Link>
                        <span>›</span>
                        <span className="current">О нас</span>
                    </div>
                </nav>
                <h1 className="text left">С ГК «Кварталика»</h1>
                <div className="text right">ваша жизнь становится</div>
                <div className="text left purple">комфортнее и безопаснее</div>
                <p className="desc">
                    Мы — девелопер полного цикла, который сочетает глубокие знания рынка с современным
                    <br />
                    видением городской среды.
                    <br />
                    Наслаждайтесь каждым днём в пространстве, созданном для жизни.
                </p>
            </section>

            <img
                className="image-2"
                src={`${FILES_BASE}/about-us-2.png`}
                alt="Команда"
                loading="lazy"
            />

            <section className="about-us-numbers">
                <div className="number-container">
                    <div className="left">
                        <img
                            className="number"
                            src={`${FILES_BASE}/01.png`}
                            alt="01"
                            loading="lazy"
                        />
                        <div className="title">
                            НАДЕЖНОСТЬ
                            <br />
                            КАК ФУНДАМЕНТ
                        </div>
                    </div>
                    <div className="right">
                        Наша репутация основана на принципах прозрачности, ответственности и соблюдения
                        сроков. Мы реализуем полный цикл работ — от проектирования до управления объектами,
                        обеспечивая надёжность на каждом этапе. Все обязательства перед клиентами
                        подкрепляются современными эскроу‑механизмами и строгим контролем качества.
                    </div>
                </div>
                <div className="number-container">
                    <div className="left">
                        <img
                            className="number"
                            src={`${FILES_BASE}/02.png`}
                            alt="02"
                            loading="lazy"
                        />
                        <div className="title">
                            ИННОВАЦИИ
                            <br />И ЭКОЛОГИЧНОСТЬ
                        </div>
                    </div>
                    <div className="right">
                        Мы интегрируем smart‑технологии, энергоэффективные системы и экологичные материалы,
                        создавая комфортную и устойчивую среду для жизни. Наш подход — синтез современной
                        архитектуры, технологических решений и бережного отношения к окружающей среде.
                    </div>
                </div>
            </section>

            <img
                src={`${FILES_BASE}/about-us-3.png`}
                alt="Проекты компании"
                className="full-image"
                loading="lazy"
            />

            <section className="about-us-values">
                <div className="section-title">Наши ценности</div>
                <div className="values-container">
                    {[
                        {
                            img: "values_1.png",
                            title: "Профессионализм",
                            desc:
                                "— экспертиза и опыт нашей команды гарантируют высочайший уровень реализации проектов",
                        },
                        {
                            img: "values_2.png",
                            title: "Качество",
                            desc:
                                "— мы используем проверенные материалы и передовые технологии строительства",
                        },
                        {
                            img: "values_3.png",
                            title: "Ответственность",
                            desc:
                                "— чёткое соблюдение обязательств перед клиентами и партнёрами",
                        },
                        {
                            img: "values_4.png",
                            title: "Устойчивое развитие",
                            desc:
                                "— создаём современную жилую среду, ориентированную на будущее",
                        },
                    ].map((v, i, arr) => (
                        <div
                            key={v.title}
                            className={`value-container ${i === arr.length - 1 ? "last" : ""}`}
                        >
                            <img
                                src={`${FILES_BASE}/${v.img}`}
                                alt={v.title}
                                loading="lazy"
                            />
                            <div className="text">
                                <div className="title">{v.title}</div>
                                <div className="desc">{v.desc}</div>
                            </div>
                            {i !== arr.length - 1 && <div className="delimiter mobile-only" />}
                        </div>
                    ))}
                    <div className="delimiters-desktop">
                        <div className="delimiter-line" />
                        <div className="delimiter-line" />
                        <div className="delimiter-line" />
                    </div>
                </div>
            </section>

            <img
                src={`${FILES_BASE}/block.png`}
                alt="Информационный блок"
                className="full-image block-gap"
                loading="lazy"
            />

            <section className="form-section">
                <img
                    className="map-bg"
                    src={`${FILES_BASE}/last_block.png`}
                    alt="Фоновая карта"
                    loading="lazy"
                />
                <form onSubmit={handleSubmit} className="form" aria-label="Форма обратной связи">
                    <div className="title">
                        Узнайте больше о наших проектах —
                        <br /> посетите офис продаж
                        <br /> или свяжитесь с нами
                    </div>
                    <div className="contacts">
                        <div className="vert">
                            <div className="contact location">
                                Томск, площадь Батенькова 2,
                                <br />
                                подъезд 7, этаж 3, офис 310
                            </div>
                            <div className="contact time">
                                Режим работы:
                                <br />
                                пн–пт: 9:00 – 19:00
                                <br />
                                сб: 10:00 – 18:00
                            </div>
                        </div>
                        <div className="vert">
                            <div className="contact phone">+7 (3822) 30-99-22</div>
                            <div className="contact mail">info@kvartalika.ru</div>
                        </div>
                    </div>
                    <div className="inputs">
                        <div className="input-wrapper">
                            <input
                                type="text"
                                required
                                value={bidForm.name}
                                onChange={e => handleInputChange("name", e.target.value)}
                                className="input"
                                placeholder="Имя*"
                            />
                        </div>
                        <div className="input-wrapper">
                            <input
                                type="tel"
                                required
                                value={bidForm.phone}
                                onChange={e => handleInputChange("phone", e.target.value)}
                                className="input"
                                placeholder="Номер телефона*"
                            />
                        </div>
                    </div>
                    <div className="submit">
                        <div className="warn">
                            Нажимая кнопку "Оставить заявку", вы соглашаетесь с{" "}
                            <a onClick={() => navigate("/privacy")}>Политикой конфиденциальности</a>
                        </div>
                        <button className="button" type="submit">
                            Оставить заявку
                        </button>
                    </div>
                </form>
            </section>
        </div>
    );
};

export default AboutUsPage;